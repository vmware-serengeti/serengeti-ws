the data is from http://www.grouplens.org/system/files/ml-100k-README.txt


