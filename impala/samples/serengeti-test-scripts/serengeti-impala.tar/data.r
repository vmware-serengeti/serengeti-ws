cat("Hello R from Impala")

